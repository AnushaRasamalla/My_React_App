
import {useParams} from "react-router-dom";
import {useSelector} from 'react-redux';

const Description = () => {

    const {id} = useParams();
    const desc = useSelector(state=>state.products);
   
    return ( <>
    <div className="container">
        <div className="row">
            <div className="col-md-10 col-sm-12 text-center pl-5 feature">
              <h2 className="" style={{fontSize:"1.5rem"}}>Product Details</h2>
              <div className=" bg-blue underline mx-auto border-bottom border-primary"></div>
            </div>

        </div>
    </div>
    <div className="container pt-5">
        <div className="row">
            <div className="col-12 col-md-6 text-center">
                <img src={`../assets/${desc[id].image}.png`} className="w-100" alt="Product_Image"/>
            </div>
            <div className="col-12 col-md-6 pt-4">
                    <h2>{desc[id].name}</h2>
                    <p className="py-2">{desc[id].body}</p>
                    <h6>Price :{desc[id].price}</h6>
                    <button className="btn btn-light w-100"><i className="bi bi-download"></i> Download</button>
            </div>
        </div>
    </div>
    </> );
}
 
export default Description;