export const addProduct = (pname,pprice,pbody,pid) => {
    return {
        type : "ADD_PROD",
        payload : {name:pname,
            price:pprice,
            body:pbody,
            id:pid,
            image :"Sample",
            download:"0"
    }
    }
}

export const delProduct = (pid) => {
    return {
        type : "DEL_PROD",
        payload : pid
    }
}

export const setProducts = (p) => {
    return {
        type : "SET_PROD",
        payload : p
    }
}