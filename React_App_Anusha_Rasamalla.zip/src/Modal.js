
import ReactDOM from 'react-dom';
import {useRef} from 'react';
import {saveProduct} from './Reducer';
import {useDispatch} from 'react-redux';

const Modal = (props) => {

    const pname = useRef(); 
    const body = useRef(); 
    const price = useRef(); 
    const dispatch = useDispatch();

    

    return ReactDOM.createPortal( <>
                <div className="modal fade" id="Modal" tabIndex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
                    <div className="modal-dialog">
                    <div className="modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title" id="ModalLabel">Add Product</h5>
                        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div className="modal-body">
                        <form>
                        <div className="form-group">
                            <label htmlFor="product-name" className="col-form-label">Name:</label>
                            <input ref={pname} type="text" className="form-control" id="product-name"/>
                        </div>
                        <div className="form-group">
                            <label htmlFor="price-text" className="col-form-label">Price:</label>
                            <input ref={price} className="form-control" id="price-text"></input>
                        </div>
                        <div className="form-group">
                            <label htmlFor="message-text" className="col-form-label">Message:</label>
                            <textarea ref={body} className="form-control" id="message-text"></textarea>
                        </div>
                        </form>
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" className="btn btn-primary" data-dismiss="modal" onClick={()=>{dispatch(saveProduct(pname.current.value,price.current.value,body.current.value))}}>Add Product</button>
                    </div>
                    </div>
                </div>
                </div>
    </>,document.getElementById("portal") );
}
 
export default Modal;