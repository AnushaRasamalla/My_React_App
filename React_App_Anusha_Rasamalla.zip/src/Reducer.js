import {combineReducers} from 'redux';
import {setProducts,addProduct} from './Action';
const intitialState = [];


export const PReducer = (state = intitialState , action) => {
    switch (action.type){
        case 'ADD_PROD' :
            return [...state,action.payload]
        case 'DEL_PROD' :
            {
                return state.filter(pro => pro.id !== action.payload)
            }
        case 'SET_PROD' :
            return [...state , ...action.payload]
        default :
            return state
    
    }
        
}

export const saveProduct = (name,price,body) => async (dispatch) => {
    let newP = await fetch('http://localhost:3000/products',{
            method:"POST",
            headers: {"content-type":"application/json"},
            body:JSON.stringify(
                {
                    name: name,
                    price: price,
                    body: body,
                    image: 'Sample',
                    download:0
                }
            )
        })
            .then(res=>res.json());
    dispatch(addProduct(name,price,body));
    alert("New product has been added with id:" + newP.id);

    }
export const fetchProducts = () => async (dispatch) => {

    let products = await fetch('http://localhost:3000/products').then(res=>res.json());
    dispatch(setProducts(products));
    //console.log(products);

}
export const Reducer = combineReducers({
    products : PReducer
});

export default Reducer;