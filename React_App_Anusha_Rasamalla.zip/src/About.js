function About() {
    return ( <>
        <div id="about" className="container mx-auto text-center " style={{paddingTop:"50px",paddingBottom:"50px"}}>
            <h1>React Js Bootcamp Assignment by Anusha Rasamalla</h1>
        </div>
    </> );
}
 
export default About;