import {Link} from "react-router-dom";
import {useDispatch} from 'react-redux';
import {delProduct} from './Action';
import "./Product.css";
const Product = (props) => {
  const dispatch = useDispatch();
    return ( 
        <div className="col-12 col-md-4 py-3">
        <div className="card">
          <img src={`../assets/${props.image}.png`} className="card-img-top" alt="Product_Image"/>
          <div className="card-body">
            <h5 className="card-title download float-right">{props.downloads} Downloads</h5>
            <h5 className="card-title">{props.title}</h5>
            <p className="card-text">{props.body}</p>
           
            <div className="row justify-content-around btn_container">
              <Link to={`/preview/${props.id}`} className="btn btn-light btn-sm"><i className="bi bi-eye-fill pr-2"></i>Preview</Link>
              <button  onClick={()=>{dispatch(delProduct(props.id))} } className="btn btn-light btn-sm"><i className="bi bi-trash pr-2"></i>Delete</button>
              <a href="/" className="btn btn-light btn-sm"><i className="bi bi-cart-fill pr-2"></i>Buy Pro</a>
            </div>
          </div>
        </div>
    </div> );
}
 
export default Product;