
import './Banner.css';
const Banner = () => {
    return ( <div>

<div className="jumbotron jumbotron-fluid" >
    <div className="container text-center" id="banner">
      <h1>Banner Title Comes Here!</h1>
      <p>Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum </p>
      <button type="button" className="btn text-white"><i className="bi bi-twitter"></i></button>
      <button type="button" className="btn text-white"><i className="bi bi-facebook"></i></button>
      <button type="button" className="btn text-white"><i className="bi bi-rss-fill"></i></button>  
      <button type="button" className="btn text-white"><i className="bi bi-envelope-fill"></i></button>
    </div>
</div>
    </div> );
}
 export default Banner;