import Product from "./Product";
import {useSelector} from "react-redux";
const Featured = () => {
  const data=useSelector(state=> state.products);
    return ( <>
    <div className="container">
          <div className="row">
            <div className="col-md-10 col-sm-12 text-center pl-5 feature">
              <h2 className="" style={{fontSize:"1.5rem"}}>Featured Products ({data.length})</h2>
              <div className=" bg-blue underline mx-auto border-bottom border-primary"></div>
            </div>
            <div className="col-md-2 col-sm-12 text-center pt-4 pt-md-0">
            <button type="button" className="btn btn-primary" data-toggle="modal" data-target="#Modal" data-whatever="@mdo">Add Product</button>
            </div>

          </div>
      </div>
  
      <div className="container">
        <div className="row justify-content-around">

          {data.map((prod)=>(
            <Product title={prod.name} downloads={prod.download} price={prod.price}  body={prod.body} image={prod.image} key={prod.id} id={prod.id}/>
          ))}
        </div>
      </div>
    </> );
}
 
export default Featured;