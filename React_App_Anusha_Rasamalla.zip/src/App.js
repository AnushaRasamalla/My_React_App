
import Navbar from "./Navbar";
import Banner from "./Banner";
import { BrowserRouter as Router, Switch, Route} from "react-router-dom";
import "./App.css";

import Modal from "./Modal"
import Featured from "./Featured"
import About from "./About";
import Description from "./Description";
import {useEffect} from 'react';
import {useDispatch} from 'react-redux';
import {fetchProducts} from './Reducer';


function App() {
  const dispatch = useDispatch();
  useEffect(()=>{
    dispatch(fetchProducts());
  },[]);


  // const [products , setProducts] = useState([
    // {name:"Softland" , body : "Softland is a modern and creative app landing HTML website template.Anyone can use this template to showcase their app and service", image:"product-image-1", download:"4062" ,price:"10$", id:1},
    // {name:"Rapid",body:"Rapid is elegant and easy to use multipurpose Bootstrap template with a modern and simplistic web design. It will leave a solid impression on everyone that", image:"product-image-2",download:"50474" ,price:"40$",id:2},
    // {name:"BizPage" , body:"BizPage is a modern,visually stunning and creative multipurpose corporate Business HTML 5 template built with Bootstrap framework. The sectioning code", image:"product-image-3",download:"102386",price:"60$",id:3}
  // ]);

  // const handleDelete = (id) =>{
      // const newProd = products.filter( pro => pro.id !== id);
      // setProducts(newProd);
      // console.log("Product Deleted!");
  // }
  // const handleAdd = (Pname , price , Pbody ) =>{

    // let newProduct = {
      // name:Pname,
      // price:price,
      // body:Pbody,
      // image:"Sample",
      // download:"0",
      // id:products.length+1
    // }

    // setProducts((pre)=>[...pre,newProduct]);
    // console.log("New Product Added");

  // }


  return (

    <div className="App">
      <Navbar/>
      <Banner/>
      <Router>
        <Switch>
        <Route exact path="/">
          <Featured/>
        {/*<Featured data={products}  handleDelete={handleDelete}/>*/}
        </Route>
        <Route exact path="/preview/:id">
          <Description/>
          {/*<Description desc={products}/>*/}
          </Route>
          
      </Switch>
      </Router>
      <About/>
      <Modal/>
     {/* <Modal handleAdd={handleAdd}/>*/}
    </div>
  
  );
}


export default App;

